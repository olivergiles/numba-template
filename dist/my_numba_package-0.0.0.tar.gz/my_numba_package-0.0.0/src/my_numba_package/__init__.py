try:
  from .my_module import *
except:
  pass
